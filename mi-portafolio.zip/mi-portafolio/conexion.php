<?php
// Conexión a la base de datos (debes completar con tus propios datos de conexión)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "contacto";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("La conexión a la base de datos falló: " . $conn->connect_error);
}

// Recuperar datos del formulario
$nombre = $_POST['nombre'];
$telefono = $_POST['telefono'];
$correo = $_POST['correo'];
$tema = $_POST['tema'];
$mensaje = $_POST['mensaje'];

// Insertar datos en la base de datos
$sql = "INSERT INTO Mensajes (Nombre, Telefono, Correo, Tema, Mensaje) VALUES ('$nombre', '$telefono', '$correo', '$tema', '$mensaje')";

if ($conn->query($sql) === TRUE) {
    echo "Mensaje enviado con éxito.";
} else {
    echo "Error al enviar el mensaje: " . $conn->error;
}

// Cerrar la conexión a la base de datos
$conn->close();
?>
